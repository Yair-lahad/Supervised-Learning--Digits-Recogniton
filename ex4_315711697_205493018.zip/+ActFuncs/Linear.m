function [g, gp] = Linear(x)
%LINEAR Linear activation function
% g     - x
% gp    - 1

g = x;
gp = 1;

end

